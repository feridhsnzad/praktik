namespace _13_NullableEnumStruct.Enums;
public enum DrinkSize
{
    Small,
    Medium,
    Large
}