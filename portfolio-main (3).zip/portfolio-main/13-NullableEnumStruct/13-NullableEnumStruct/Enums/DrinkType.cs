namespace _13_NullableEnumStruct.Enums;

public enum DrinkType
{
    Coffee,
    Tea,
    Juice,
    Water
}