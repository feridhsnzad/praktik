namespace _13_NullableEnumStruct.Enums;

public enum OrderStatus
{
    New,
    Preparing,
    Ready,
    Delivered
}