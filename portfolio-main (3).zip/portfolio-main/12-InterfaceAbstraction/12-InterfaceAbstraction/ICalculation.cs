namespace _12_InterfaceAbstraction;

public interface ICalculation
{
    double  Sum();
    double Substraction();
    double Multiplication();
    double Division();
}